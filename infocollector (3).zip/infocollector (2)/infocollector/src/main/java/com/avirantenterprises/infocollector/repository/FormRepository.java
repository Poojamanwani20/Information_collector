package com.avirantenterprises.infocollector.repository;

import com.avirantenterprises.infocollector.model.Form;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FormRepository extends JpaRepository<Form, Long> {
}
